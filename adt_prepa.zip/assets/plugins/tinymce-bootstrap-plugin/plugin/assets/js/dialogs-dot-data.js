var dotData = {
    choiceTitleClass: 'choice-title mt-n3 mb-1',
    codeClass: 'w-100',
    codeSectionClass: 'd-flex flex-wrap justify-content-center align-items-center py-3',
    previewClass: 'p-2 w-100',
    previewSectionClass: 'd-flex flex-wrap justify-content-center align-items-center py-3',
    sectionClass: 'd-flex flex-wrap justify-content-center align-items-center pt-3 pb-2',
    sectionRowSplitClass: 'pt-3 pb-2',
    sectionRowSplitColClass: 'col-12 d-flex flex-wrap justify-content-center align-items-center',
    sectionSplitClass: 'pt-3 pb-2',
    sectionSplitColClass: 'col-12 col-sm-6 d-flex flex-wrap justify-content-center align-items-center'
};
