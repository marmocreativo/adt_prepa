<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-11-24 21:35:19 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'adt_prepa'@'localhost' (using password: YES) D:\xampp\htdocs\adt_prepa\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2020-11-24 21:35:19 --> Unable to connect to the database
ERROR - 2020-11-24 21:35:19 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'adt_prepa'@'localhost' (using password: YES) D:\xampp\htdocs\adt_prepa\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2020-11-24 21:35:19 --> Unable to connect to the database
ERROR - 2020-11-24 21:35:19 --> Query error: Access denied for user 'adt_prepa'@'localhost' (using password: YES) - Invalid query: SHOW TABLES FROM `adt_prepa`
ERROR - 2020-11-24 21:35:19 --> Severity: error --> Exception: Call to a member function result_array() on boolean D:\xampp\htdocs\adt_prepa\system\database\DB_driver.php 1257
ERROR - 2020-11-24 21:53:46 --> 404 Page Not Found: Admin_Tareas/detalles
