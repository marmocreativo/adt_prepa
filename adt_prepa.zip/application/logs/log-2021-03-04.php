<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-03-04 21:30:49 --> 404 Page Not Found: Usuarios_Inicio/proyectos
ERROR - 2021-03-04 21:31:09 --> 404 Page Not Found: Usuarios_Inicio/equipos
ERROR - 2021-03-04 21:54:18 --> 404 Page Not Found: Admin_Tareas/detalles
