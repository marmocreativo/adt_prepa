<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-09 05:58:14 --> 404 Page Not Found: Usuarios_Inicio/equipos
ERROR - 2020-09-09 06:00:45 --> Severity: Warning --> Creating default object from empty value D:\xampp\htdocs\adt_prepa\application\controllers\Admin_Proyectos.php 245
ERROR - 2020-09-09 06:01:03 --> 404 Page Not Found: Admin_Tareas/detalles
ERROR - 2020-09-09 06:01:15 --> 404 Page Not Found: Admin_Tareas/detalles
