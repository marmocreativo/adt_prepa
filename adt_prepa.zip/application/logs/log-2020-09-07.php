<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-07 08:24:14 --> 404 Page Not Found: Usuarios_Inicio/equipos
ERROR - 2020-09-07 08:24:43 --> 404 Page Not Found: Admin_Tareas/detalles
ERROR - 2020-09-07 08:24:55 --> 404 Page Not Found: Admin_Tareas/detalles
