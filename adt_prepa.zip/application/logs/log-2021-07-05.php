<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-07-05 02:54:44 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ')' D:\xampp\htdocs\adt_prepa\application\views\default\front\headers\header_principal.php 90
ERROR - 2021-07-05 03:40:40 --> 404 Page Not Found: Front_Tareas/index
ERROR - 2021-07-05 03:41:26 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_tareas.php 57
ERROR - 2021-07-05 03:42:33 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_tareas.php 58
ERROR - 2021-07-05 03:43:29 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_tareas.php 58
ERROR - 2021-07-05 03:43:54 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_tareas.php 58
ERROR - 2021-07-05 03:44:11 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_tareas.php 58
ERROR - 2021-07-05 03:48:38 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_tareas.php 106
ERROR - 2021-07-05 03:49:46 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_tareas.php 71
ERROR - 2021-07-05 03:49:55 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_tareas.php 71
ERROR - 2021-07-05 03:51:09 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_tareas.php 96
ERROR - 2021-07-05 03:51:21 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_tareas.php 96
ERROR - 2021-07-05 03:52:07 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_tareas.php 80
ERROR - 2021-07-05 03:52:25 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_tareas.php 84
ERROR - 2021-07-05 03:52:32 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_tareas.php 84
ERROR - 2021-07-05 03:56:53 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_tareas.php 93
ERROR - 2021-07-05 03:56:53 --> 404 Page Not Found: Contenido/img
ERROR - 2021-07-05 03:56:53 --> 404 Page Not Found: Contenido/img
ERROR - 2021-07-05 03:57:11 --> 404 Page Not Found: Contenido/img
ERROR - 2021-07-05 03:57:20 --> 404 Page Not Found: Contenido/img
ERROR - 2021-07-05 03:57:22 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_tareas.php 93
ERROR - 2021-07-05 03:57:38 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_tareas.php 93
ERROR - 2021-07-05 03:59:20 --> 404 Page Not Found: Front_Proyectos/index
ERROR - 2021-07-05 03:59:41 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_tareas.php 93
ERROR - 2021-07-05 03:59:54 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_proyectos.php 48
ERROR - 2021-07-05 04:09:21 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_proyectos.php 115
ERROR - 2021-07-05 04:11:25 --> 404 Page Not Found: Front_Equipos/index
ERROR - 2021-07-05 04:12:16 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_equipos.php 48
ERROR - 2021-07-05 04:12:40 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_equipos.php 49
ERROR - 2021-07-05 04:12:49 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_equipos.php 49
ERROR - 2021-07-05 04:15:03 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_equipos.php 61
ERROR - 2021-07-05 04:15:44 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_equipos.php 63
ERROR - 2021-07-05 04:15:55 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_equipos.php 63
ERROR - 2021-07-05 04:16:06 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_equipos.php 63
ERROR - 2021-07-05 04:16:27 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_equipos.php 63
ERROR - 2021-07-05 04:17:57 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_equipos.php 78
ERROR - 2021-07-05 04:18:06 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_equipos.php 78
ERROR - 2021-07-05 04:18:25 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_equipos.php 78
ERROR - 2021-07-05 04:18:29 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_equipos.php 78
ERROR - 2021-07-05 04:18:35 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_equipos.php 78
ERROR - 2021-07-05 04:18:43 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_equipos.php 78
ERROR - 2021-07-05 04:19:31 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_equipos.php 81
ERROR - 2021-07-05 04:19:45 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_equipos.php 81
ERROR - 2021-07-05 04:42:05 --> Severity: Warning --> Division by zero D:\xampp\htdocs\adt_prepa\application\controllers\Front_Equipos.php 64
ERROR - 2021-07-05 04:42:05 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\adt_prepa\application\controllers\Front_Equipos.php 69
ERROR - 2021-07-05 04:42:05 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\adt_prepa\application\controllers\Front_Equipos.php 75
ERROR - 2021-07-05 04:42:05 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\adt_prepa\application\controllers\Front_Equipos.php 81
ERROR - 2021-07-05 04:42:26 --> Severity: Warning --> Division by zero D:\xampp\htdocs\adt_prepa\application\controllers\Front_Equipos.php 64
ERROR - 2021-07-05 04:42:26 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\adt_prepa\application\controllers\Front_Equipos.php 69
ERROR - 2021-07-05 04:42:26 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\adt_prepa\application\controllers\Front_Equipos.php 75
ERROR - 2021-07-05 04:42:26 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\adt_prepa\application\controllers\Front_Equipos.php 81
ERROR - 2021-07-05 04:43:34 --> Severity: Warning --> Division by zero D:\xampp\htdocs\adt_prepa\application\controllers\Front_Equipos.php 64
ERROR - 2021-07-05 04:43:34 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\adt_prepa\application\controllers\Front_Equipos.php 69
ERROR - 2021-07-05 04:43:34 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\adt_prepa\application\controllers\Front_Equipos.php 75
ERROR - 2021-07-05 04:43:34 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\adt_prepa\application\controllers\Front_Equipos.php 81
ERROR - 2021-07-05 04:49:22 --> Severity: Warning --> Division by zero D:\xampp\htdocs\adt_prepa\application\controllers\Front_Equipos.php 64
ERROR - 2021-07-05 04:49:22 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\adt_prepa\application\controllers\Front_Equipos.php 69
ERROR - 2021-07-05 04:49:22 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\adt_prepa\application\controllers\Front_Equipos.php 75
ERROR - 2021-07-05 04:49:22 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\adt_prepa\application\controllers\Front_Equipos.php 81
ERROR - 2021-07-05 04:49:25 --> 404 Page Not Found: Equpos/detalles
ERROR - 2021-07-05 04:49:27 --> Severity: Warning --> Division by zero D:\xampp\htdocs\adt_prepa\application\controllers\Front_Equipos.php 64
ERROR - 2021-07-05 04:49:27 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\adt_prepa\application\controllers\Front_Equipos.php 69
ERROR - 2021-07-05 04:49:27 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\adt_prepa\application\controllers\Front_Equipos.php 75
ERROR - 2021-07-05 04:49:27 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\adt_prepa\application\controllers\Front_Equipos.php 81
ERROR - 2021-07-05 04:52:07 --> Severity: Warning --> Division by zero D:\xampp\htdocs\adt_prepa\application\controllers\Front_Equipos.php 73
ERROR - 2021-07-05 04:52:07 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\adt_prepa\application\controllers\Front_Equipos.php 78
ERROR - 2021-07-05 04:52:07 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\adt_prepa\application\controllers\Front_Equipos.php 84
ERROR - 2021-07-05 04:52:07 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\adt_prepa\application\controllers\Front_Equipos.php 90
ERROR - 2021-07-05 04:52:23 --> Severity: Notice --> Undefined variable: op D:\xampp\htdocs\adt_prepa\application\controllers\Front_Equipos.php 49
ERROR - 2021-07-05 04:52:23 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\controllers\Front_Equipos.php 49
ERROR - 2021-07-05 04:52:23 --> Severity: Warning --> Division by zero D:\xampp\htdocs\adt_prepa\application\controllers\Front_Equipos.php 73
ERROR - 2021-07-05 04:52:23 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\adt_prepa\application\controllers\Front_Equipos.php 78
ERROR - 2021-07-05 04:52:23 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\adt_prepa\application\controllers\Front_Equipos.php 84
ERROR - 2021-07-05 04:52:23 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\adt_prepa\application\controllers\Front_Equipos.php 90
ERROR - 2021-07-05 04:52:23 --> Severity: Notice --> Undefined index: tipo_objeto D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_equipos.php 125
ERROR - 2021-07-05 04:52:23 --> Severity: Notice --> Undefined index: tipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_equipos.php 126
ERROR - 2021-07-05 04:52:23 --> Severity: Notice --> Undefined index: padre D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_equipos.php 127
ERROR - 2021-07-05 04:52:43 --> Severity: Notice --> Undefined index: mostrar_por_pagina D:\xampp\htdocs\adt_prepa\application\controllers\Front_Equipos.php 49
ERROR - 2021-07-05 04:52:43 --> Severity: Warning --> Division by zero D:\xampp\htdocs\adt_prepa\application\controllers\Front_Equipos.php 73
ERROR - 2021-07-05 04:52:43 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\adt_prepa\application\controllers\Front_Equipos.php 78
ERROR - 2021-07-05 04:52:43 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\adt_prepa\application\controllers\Front_Equipos.php 84
ERROR - 2021-07-05 04:52:43 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\adt_prepa\application\controllers\Front_Equipos.php 90
ERROR - 2021-07-05 04:52:43 --> Severity: Notice --> Undefined index: tipo_objeto D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_equipos.php 125
ERROR - 2021-07-05 04:52:43 --> Severity: Notice --> Undefined index: tipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_equipos.php 126
ERROR - 2021-07-05 04:52:43 --> Severity: Notice --> Undefined index: padre D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_equipos.php 127
ERROR - 2021-07-05 04:53:18 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\adt_prepa\application\controllers\Front_Equipos.php 78
ERROR - 2021-07-05 04:53:18 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\adt_prepa\application\controllers\Front_Equipos.php 84
ERROR - 2021-07-05 04:53:18 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\adt_prepa\application\controllers\Front_Equipos.php 90
ERROR - 2021-07-05 04:53:18 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-12, 12' at line 6 - Invalid query: SELECT *
FROM `equipos`
WHERE   (
`equipos`.`ESTADO` = 'activo'
 )
 LIMIT -12, 12
ERROR - 2021-07-05 04:54:02 --> Severity: Notice --> Undefined variable: consulta D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_tareas.php 45
ERROR - 2021-07-05 04:54:02 --> Severity: Notice --> Undefined variable: tareas D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_tareas.php 93
ERROR - 2021-07-05 04:54:02 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_tareas.php 93
ERROR - 2021-07-05 04:54:02 --> Severity: Notice --> Undefined variable: cantidad_paginas D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_tareas.php 127
ERROR - 2021-07-05 04:54:03 --> Severity: Notice --> Undefined variable: consulta D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_proyectos.php 76
ERROR - 2021-07-05 04:54:03 --> Severity: Notice --> Undefined variable: proyectos D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_proyectos.php 115
ERROR - 2021-07-05 04:54:03 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_proyectos.php 115
ERROR - 2021-07-05 04:54:03 --> Severity: Notice --> Undefined variable: cantidad_paginas D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_proyectos.php 132
ERROR - 2021-07-05 04:57:24 --> 404 Page Not Found: Front_Proyectos/busqueda
ERROR - 2021-07-05 04:58:44 --> Severity: Notice --> Undefined variable: categoria D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_equipos.php 52
ERROR - 2021-07-05 04:58:44 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_equipos.php 52
ERROR - 2021-07-05 04:58:44 --> Severity: Notice --> Undefined variable: categoria D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_equipos.php 55
ERROR - 2021-07-05 04:58:44 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_equipos.php 55
ERROR - 2021-07-05 04:58:44 --> Severity: Notice --> Undefined variable: categoria D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_equipos.php 69
ERROR - 2021-07-05 04:58:44 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_equipos.php 69
ERROR - 2021-07-05 04:58:44 --> Severity: Notice --> Undefined index: tipo_objeto D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_equipos.php 165
ERROR - 2021-07-05 04:58:44 --> Severity: Notice --> Undefined index: tipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_equipos.php 166
ERROR - 2021-07-05 04:58:44 --> Severity: Notice --> Undefined index: padre D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_equipos.php 167
ERROR - 2021-07-05 05:00:14 --> Severity: Notice --> Undefined index: tipo_objeto D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_equipos.php 165
ERROR - 2021-07-05 05:00:14 --> Severity: Notice --> Undefined index: tipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_equipos.php 166
ERROR - 2021-07-05 05:00:14 --> Severity: Notice --> Undefined index: padre D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_equipos.php 167
ERROR - 2021-07-05 05:00:16 --> Severity: Notice --> Undefined index: tipo_objeto D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_equipos.php 165
ERROR - 2021-07-05 05:00:16 --> Severity: Notice --> Undefined index: tipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_equipos.php 166
ERROR - 2021-07-05 05:00:16 --> Severity: Notice --> Undefined index: padre D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_equipos.php 167
ERROR - 2021-07-05 05:00:17 --> Severity: Notice --> Undefined index: tipo_objeto D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_equipos.php 165
ERROR - 2021-07-05 05:00:17 --> Severity: Notice --> Undefined index: tipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_equipos.php 166
ERROR - 2021-07-05 05:00:17 --> Severity: Notice --> Undefined index: padre D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_equipos.php 167
ERROR - 2021-07-05 05:00:18 --> Severity: Notice --> Undefined index: tipo_objeto D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_equipos.php 165
ERROR - 2021-07-05 05:00:18 --> Severity: Notice --> Undefined index: tipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_equipos.php 166
ERROR - 2021-07-05 05:00:18 --> Severity: Notice --> Undefined index: padre D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_equipos.php 167
ERROR - 2021-07-05 05:00:20 --> Severity: Notice --> Undefined index: tipo_objeto D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_equipos.php 165
ERROR - 2021-07-05 05:00:20 --> Severity: Notice --> Undefined index: tipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_equipos.php 166
ERROR - 2021-07-05 05:00:20 --> Severity: Notice --> Undefined index: padre D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_equipos.php 167
ERROR - 2021-07-05 05:09:57 --> Severity: Notice --> Undefined index: usuario D:\xampp\htdocs\adt_prepa\application\controllers\Front_Equipos.php 67
ERROR - 2021-07-05 05:09:57 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\controllers\Front_Equipos.php 67
ERROR - 2021-07-05 05:12:49 --> 404 Page Not Found: Admin/equipos
ERROR - 2021-07-05 05:15:26 --> 404 Page Not Found: Front_Equipos/actualizar
ERROR - 2021-07-05 05:17:03 --> Severity: Notice --> Undefined variable: titulo D:\xampp\htdocs\adt_prepa\application\views\default\front\headers\header_principal.php 8
ERROR - 2021-07-05 05:17:03 --> Severity: Notice --> Undefined variable: titulo D:\xampp\htdocs\adt_prepa\application\views\default\front\headers\header_principal.php 13
ERROR - 2021-07-05 05:17:03 --> Severity: Notice --> Undefined variable: descripcion D:\xampp\htdocs\adt_prepa\application\views\default\front\headers\header_principal.php 14
ERROR - 2021-07-05 05:17:03 --> Severity: Notice --> Undefined variable: imagen D:\xampp\htdocs\adt_prepa\application\views\default\front\headers\header_principal.php 15
ERROR - 2021-07-05 05:17:03 --> Severity: Notice --> Undefined variable: titulo D:\xampp\htdocs\adt_prepa\application\views\default\front\headers\header_principal.php 84
ERROR - 2021-07-05 05:20:27 --> 404 Page Not Found: Admin/equipos
ERROR - 2021-07-05 05:20:31 --> Severity: Notice --> Undefined index: id D:\xampp\htdocs\adt_prepa\application\controllers\Front_Equipos.php 287
ERROR - 2021-07-05 05:20:31 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\controllers\Front_Equipos.php 288
ERROR - 2021-07-05 05:20:31 --> Severity: Notice --> Undefined index: id D:\xampp\htdocs\adt_prepa\application\controllers\Front_Equipos.php 294
ERROR - 2021-07-05 05:20:31 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 4
ERROR - 2021-07-05 05:20:31 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 6
ERROR - 2021-07-05 05:20:31 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 7
ERROR - 2021-07-05 05:20:31 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 8
ERROR - 2021-07-05 05:20:31 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 9
ERROR - 2021-07-05 05:20:31 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 32
ERROR - 2021-07-05 05:20:32 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 33
ERROR - 2021-07-05 05:20:32 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 37
ERROR - 2021-07-05 05:20:32 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 41
ERROR - 2021-07-05 05:20:32 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 05:20:32 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 05:20:32 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 05:20:32 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 05:20:32 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 05:20:32 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 05:20:32 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 05:20:32 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 05:20:32 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 05:20:32 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 05:20:32 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 05:20:32 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 05:20:32 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 05:20:32 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 05:20:32 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 05:20:32 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 05:20:32 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 65
ERROR - 2021-07-05 05:20:32 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 88
ERROR - 2021-07-05 05:20:32 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 89
ERROR - 2021-07-05 05:20:32 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 93
ERROR - 2021-07-05 05:20:32 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 99
ERROR - 2021-07-05 05:22:22 --> 404 Page Not Found: Front_Equipos/detalles
ERROR - 2021-07-05 06:36:17 --> Severity: Warning --> Creating default object from empty value D:\xampp\htdocs\adt_prepa\application\controllers\Front_Proyectos.php 55
ERROR - 2021-07-05 06:36:17 --> Query error: Column 'TIPO' cannot be null - Invalid query: INSERT INTO `proyectos` (`PROYECTO_NOMBRE`, `URL`, `PROYECTO_DESCRIPCION`, `IMAGEN`, `IMAGEN_FONDO`, `TIPO`, `ESTADO`, `ORDEN`) VALUES ('Proyecto Z4RA', 'borrador-Z4RA', '', 'default.jpg', 'fondo_default.jpg', NULL, 'activo', 0)
ERROR - 2021-07-05 06:36:41 --> Query error: Column 'TIPO' cannot be null - Invalid query: INSERT INTO `proyectos` (`PROYECTO_NOMBRE`, `URL`, `PROYECTO_DESCRIPCION`, `IMAGEN`, `IMAGEN_FONDO`, `TIPO`, `ESTADO`, `ORDEN`) VALUES ('Proyecto 2PVZ', 'borrador-2PVZ', '', 'default.jpg', 'fondo_default.jpg', NULL, 'activo', 0)
ERROR - 2021-07-05 06:36:58 --> Severity: Notice --> Undefined variable: consulta D:\xampp\htdocs\adt_prepa\application\controllers\Front_Proyectos.php 91
ERROR - 2021-07-05 06:36:58 --> 404 Page Not Found: Front_Proyectos/actualizar
ERROR - 2021-07-05 07:47:49 --> Severity: Notice --> Undefined variable: consulta D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_proyectos.php 76
ERROR - 2021-07-05 07:47:49 --> Severity: Notice --> Undefined variable: proyectos D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_proyectos.php 115
ERROR - 2021-07-05 07:47:49 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_proyectos.php 115
ERROR - 2021-07-05 07:47:49 --> Severity: Notice --> Undefined variable: cantidad_paginas D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_proyectos.php 132
ERROR - 2021-07-05 07:47:55 --> Severity: Notice --> Undefined variable: consulta D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_tareas.php 45
ERROR - 2021-07-05 07:47:55 --> Severity: Notice --> Undefined variable: tareas D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_tareas.php 93
ERROR - 2021-07-05 07:47:55 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_tareas.php 93
ERROR - 2021-07-05 07:47:55 --> Severity: Notice --> Undefined variable: cantidad_paginas D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_tareas.php 127
ERROR - 2021-07-05 07:47:58 --> Severity: Notice --> Undefined variable: consulta D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_proyectos.php 76
ERROR - 2021-07-05 07:47:58 --> Severity: Notice --> Undefined variable: proyectos D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_proyectos.php 115
ERROR - 2021-07-05 07:47:58 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_proyectos.php 115
ERROR - 2021-07-05 07:47:58 --> Severity: Notice --> Undefined variable: cantidad_paginas D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_proyectos.php 132
ERROR - 2021-07-05 07:48:03 --> 404 Page Not Found: Equpos/detalles
ERROR - 2021-07-05 08:10:58 --> Severity: Notice --> Undefined variable: consulta D:\xampp\htdocs\adt_prepa\application\controllers\Front_Proyectos.php 90
ERROR - 2021-07-05 08:10:59 --> Severity: Notice --> Undefined index: equipo D:\xampp\htdocs\adt_prepa\application\controllers\Front_Proyectos.php 216
ERROR - 2021-07-05 08:10:59 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\controllers\Front_Proyectos.php 216
ERROR - 2021-07-05 08:10:59 --> Severity: Notice --> Undefined variable: titulo D:\xampp\htdocs\adt_prepa\application\views\default\front\headers\header_principal.php 8
ERROR - 2021-07-05 08:10:59 --> Severity: Notice --> Undefined variable: titulo D:\xampp\htdocs\adt_prepa\application\views\default\front\headers\header_principal.php 13
ERROR - 2021-07-05 08:10:59 --> Severity: Notice --> Undefined variable: descripcion D:\xampp\htdocs\adt_prepa\application\views\default\front\headers\header_principal.php 14
ERROR - 2021-07-05 08:10:59 --> Severity: Notice --> Undefined variable: imagen D:\xampp\htdocs\adt_prepa\application\views\default\front\headers\header_principal.php 15
ERROR - 2021-07-05 08:10:59 --> Severity: Notice --> Undefined variable: titulo D:\xampp\htdocs\adt_prepa\application\views\default\front\headers\header_principal.php 84
ERROR - 2021-07-05 08:10:59 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 4
ERROR - 2021-07-05 08:10:59 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 4
ERROR - 2021-07-05 08:10:59 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 6
ERROR - 2021-07-05 08:10:59 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 6
ERROR - 2021-07-05 08:10:59 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 7
ERROR - 2021-07-05 08:10:59 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 7
ERROR - 2021-07-05 08:10:59 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 8
ERROR - 2021-07-05 08:10:59 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 8
ERROR - 2021-07-05 08:10:59 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 9
ERROR - 2021-07-05 08:10:59 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 9
ERROR - 2021-07-05 08:10:59 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 32
ERROR - 2021-07-05 08:10:59 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 32
ERROR - 2021-07-05 08:10:59 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 33
ERROR - 2021-07-05 08:10:59 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 33
ERROR - 2021-07-05 08:10:59 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 37
ERROR - 2021-07-05 08:10:59 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 37
ERROR - 2021-07-05 08:10:59 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 41
ERROR - 2021-07-05 08:10:59 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 41
ERROR - 2021-07-05 08:10:59 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 08:10:59 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 08:10:59 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 08:10:59 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 08:10:59 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 08:10:59 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 08:10:59 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 08:10:59 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 08:10:59 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 08:10:59 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 08:10:59 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 08:10:59 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 08:10:59 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 08:10:59 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 08:10:59 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 08:10:59 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 08:10:59 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 08:10:59 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 08:10:59 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 08:10:59 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 08:10:59 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 08:10:59 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 08:10:59 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 08:10:59 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 08:10:59 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 08:10:59 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 08:10:59 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 08:10:59 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 08:10:59 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 08:10:59 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 08:10:59 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 08:10:59 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 08:10:59 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 65
ERROR - 2021-07-05 08:10:59 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 65
ERROR - 2021-07-05 08:10:59 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 88
ERROR - 2021-07-05 08:10:59 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 88
ERROR - 2021-07-05 08:10:59 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 89
ERROR - 2021-07-05 08:10:59 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 89
ERROR - 2021-07-05 08:10:59 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 93
ERROR - 2021-07-05 08:10:59 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 93
ERROR - 2021-07-05 08:10:59 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 99
ERROR - 2021-07-05 08:10:59 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 99
ERROR - 2021-07-05 08:11:23 --> Severity: Notice --> Undefined variable: titulo D:\xampp\htdocs\adt_prepa\application\views\default\front\headers\header_principal.php 8
ERROR - 2021-07-05 08:11:23 --> Severity: Notice --> Undefined variable: titulo D:\xampp\htdocs\adt_prepa\application\views\default\front\headers\header_principal.php 13
ERROR - 2021-07-05 08:11:23 --> Severity: Notice --> Undefined variable: descripcion D:\xampp\htdocs\adt_prepa\application\views\default\front\headers\header_principal.php 14
ERROR - 2021-07-05 08:11:23 --> Severity: Notice --> Undefined variable: imagen D:\xampp\htdocs\adt_prepa\application\views\default\front\headers\header_principal.php 15
ERROR - 2021-07-05 08:11:23 --> Severity: Notice --> Undefined variable: titulo D:\xampp\htdocs\adt_prepa\application\views\default\front\headers\header_principal.php 84
ERROR - 2021-07-05 08:11:23 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 4
ERROR - 2021-07-05 08:11:23 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 4
ERROR - 2021-07-05 08:11:23 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 6
ERROR - 2021-07-05 08:11:23 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 6
ERROR - 2021-07-05 08:11:23 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 7
ERROR - 2021-07-05 08:11:23 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 7
ERROR - 2021-07-05 08:11:23 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 8
ERROR - 2021-07-05 08:11:23 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 8
ERROR - 2021-07-05 08:11:23 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 9
ERROR - 2021-07-05 08:11:23 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 9
ERROR - 2021-07-05 08:11:23 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 32
ERROR - 2021-07-05 08:11:23 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 32
ERROR - 2021-07-05 08:11:23 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 33
ERROR - 2021-07-05 08:11:23 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 33
ERROR - 2021-07-05 08:11:23 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 37
ERROR - 2021-07-05 08:11:23 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 37
ERROR - 2021-07-05 08:11:23 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 41
ERROR - 2021-07-05 08:11:23 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 41
ERROR - 2021-07-05 08:11:23 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 08:11:23 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 08:11:23 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 08:11:23 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 08:11:23 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 08:11:23 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 08:11:23 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 08:11:23 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 08:11:23 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 08:11:23 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 08:11:23 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 08:11:23 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 08:11:23 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 08:11:23 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 08:11:23 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 08:11:23 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 08:11:23 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 08:11:23 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 08:11:23 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 08:11:23 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 08:11:23 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 08:11:23 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 08:11:23 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 08:11:23 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 08:11:23 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 08:11:23 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 08:11:23 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 08:11:23 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 08:11:23 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 08:11:23 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 08:11:23 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 08:11:23 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 08:11:23 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 65
ERROR - 2021-07-05 08:11:23 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 65
ERROR - 2021-07-05 08:11:23 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 88
ERROR - 2021-07-05 08:11:23 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 88
ERROR - 2021-07-05 08:11:23 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 89
ERROR - 2021-07-05 08:11:23 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 89
ERROR - 2021-07-05 08:11:23 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 93
ERROR - 2021-07-05 08:11:23 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 93
ERROR - 2021-07-05 08:11:23 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 99
ERROR - 2021-07-05 08:11:23 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 99
ERROR - 2021-07-05 08:11:59 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 4
ERROR - 2021-07-05 08:11:59 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 4
ERROR - 2021-07-05 08:11:59 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 6
ERROR - 2021-07-05 08:11:59 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 6
ERROR - 2021-07-05 08:11:59 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 7
ERROR - 2021-07-05 08:11:59 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 7
ERROR - 2021-07-05 08:11:59 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 8
ERROR - 2021-07-05 08:11:59 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 8
ERROR - 2021-07-05 08:11:59 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 9
ERROR - 2021-07-05 08:11:59 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 9
ERROR - 2021-07-05 08:11:59 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 32
ERROR - 2021-07-05 08:11:59 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 32
ERROR - 2021-07-05 08:11:59 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 33
ERROR - 2021-07-05 08:11:59 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 33
ERROR - 2021-07-05 08:11:59 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 37
ERROR - 2021-07-05 08:11:59 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 37
ERROR - 2021-07-05 08:11:59 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 41
ERROR - 2021-07-05 08:11:59 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 41
ERROR - 2021-07-05 08:11:59 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 08:11:59 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 08:11:59 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 08:11:59 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 08:11:59 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 08:11:59 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 08:11:59 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 08:11:59 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 08:11:59 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 08:11:59 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 08:11:59 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 08:11:59 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 08:11:59 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 08:11:59 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 08:11:59 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 08:11:59 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 08:11:59 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 08:11:59 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 08:11:59 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 08:11:59 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 08:11:59 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 08:11:59 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 08:11:59 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 08:11:59 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 08:11:59 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 08:11:59 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 08:11:59 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 08:11:59 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 08:11:59 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 08:11:59 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 08:11:59 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 08:11:59 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 54
ERROR - 2021-07-05 08:11:59 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 65
ERROR - 2021-07-05 08:11:59 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 65
ERROR - 2021-07-05 08:11:59 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 88
ERROR - 2021-07-05 08:11:59 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 88
ERROR - 2021-07-05 08:11:59 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 89
ERROR - 2021-07-05 08:11:59 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 89
ERROR - 2021-07-05 08:11:59 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 93
ERROR - 2021-07-05 08:11:59 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 93
ERROR - 2021-07-05 08:11:59 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 99
ERROR - 2021-07-05 08:11:59 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 99
ERROR - 2021-07-05 08:12:33 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 3
ERROR - 2021-07-05 08:12:33 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 3
ERROR - 2021-07-05 08:12:33 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 5
ERROR - 2021-07-05 08:12:33 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 5
ERROR - 2021-07-05 08:12:33 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 6
ERROR - 2021-07-05 08:12:33 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 6
ERROR - 2021-07-05 08:12:33 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 7
ERROR - 2021-07-05 08:12:33 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 7
ERROR - 2021-07-05 08:12:33 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 8
ERROR - 2021-07-05 08:12:33 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 8
ERROR - 2021-07-05 08:12:33 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 31
ERROR - 2021-07-05 08:12:33 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 31
ERROR - 2021-07-05 08:12:33 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 32
ERROR - 2021-07-05 08:12:33 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 32
ERROR - 2021-07-05 08:12:33 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 36
ERROR - 2021-07-05 08:12:33 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 36
ERROR - 2021-07-05 08:12:33 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 40
ERROR - 2021-07-05 08:12:33 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 40
ERROR - 2021-07-05 08:12:33 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 53
ERROR - 2021-07-05 08:12:33 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 53
ERROR - 2021-07-05 08:12:33 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 53
ERROR - 2021-07-05 08:12:33 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 53
ERROR - 2021-07-05 08:12:33 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 53
ERROR - 2021-07-05 08:12:33 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 53
ERROR - 2021-07-05 08:12:33 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 53
ERROR - 2021-07-05 08:12:33 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 53
ERROR - 2021-07-05 08:12:33 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 53
ERROR - 2021-07-05 08:12:33 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 53
ERROR - 2021-07-05 08:12:33 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 53
ERROR - 2021-07-05 08:12:33 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 53
ERROR - 2021-07-05 08:12:33 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 53
ERROR - 2021-07-05 08:12:33 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 53
ERROR - 2021-07-05 08:12:33 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 53
ERROR - 2021-07-05 08:12:33 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 53
ERROR - 2021-07-05 08:12:33 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 53
ERROR - 2021-07-05 08:12:33 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 53
ERROR - 2021-07-05 08:12:33 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 53
ERROR - 2021-07-05 08:12:33 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 53
ERROR - 2021-07-05 08:12:33 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 53
ERROR - 2021-07-05 08:12:33 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 53
ERROR - 2021-07-05 08:12:33 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 53
ERROR - 2021-07-05 08:12:33 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 53
ERROR - 2021-07-05 08:12:33 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 53
ERROR - 2021-07-05 08:12:33 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 53
ERROR - 2021-07-05 08:12:33 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 53
ERROR - 2021-07-05 08:12:33 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 53
ERROR - 2021-07-05 08:12:33 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 53
ERROR - 2021-07-05 08:12:33 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 53
ERROR - 2021-07-05 08:12:33 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 53
ERROR - 2021-07-05 08:12:33 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 53
ERROR - 2021-07-05 08:12:33 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 64
ERROR - 2021-07-05 08:12:33 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 64
ERROR - 2021-07-05 08:12:33 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 87
ERROR - 2021-07-05 08:12:33 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 87
ERROR - 2021-07-05 08:12:33 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 88
ERROR - 2021-07-05 08:12:33 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 88
ERROR - 2021-07-05 08:12:33 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 92
ERROR - 2021-07-05 08:12:33 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 92
ERROR - 2021-07-05 08:12:33 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 98
ERROR - 2021-07-05 08:12:33 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 98
ERROR - 2021-07-05 08:12:56 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 3
ERROR - 2021-07-05 08:12:56 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 3
ERROR - 2021-07-05 08:12:56 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 5
ERROR - 2021-07-05 08:12:56 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 5
ERROR - 2021-07-05 08:12:56 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 6
ERROR - 2021-07-05 08:12:56 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 6
ERROR - 2021-07-05 08:12:56 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 7
ERROR - 2021-07-05 08:12:56 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 7
ERROR - 2021-07-05 08:12:56 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 8
ERROR - 2021-07-05 08:12:56 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 8
ERROR - 2021-07-05 08:12:56 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 31
ERROR - 2021-07-05 08:12:56 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 31
ERROR - 2021-07-05 08:12:56 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 32
ERROR - 2021-07-05 08:12:56 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 32
ERROR - 2021-07-05 08:12:56 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 36
ERROR - 2021-07-05 08:12:56 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 36
ERROR - 2021-07-05 08:12:56 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 40
ERROR - 2021-07-05 08:12:56 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 40
ERROR - 2021-07-05 08:12:56 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 53
ERROR - 2021-07-05 08:12:56 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 53
ERROR - 2021-07-05 08:12:56 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 53
ERROR - 2021-07-05 08:12:56 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 53
ERROR - 2021-07-05 08:12:56 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 53
ERROR - 2021-07-05 08:12:56 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 53
ERROR - 2021-07-05 08:12:56 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 53
ERROR - 2021-07-05 08:12:56 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 53
ERROR - 2021-07-05 08:12:56 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 53
ERROR - 2021-07-05 08:12:56 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 53
ERROR - 2021-07-05 08:12:56 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 53
ERROR - 2021-07-05 08:12:56 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 53
ERROR - 2021-07-05 08:12:56 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 53
ERROR - 2021-07-05 08:12:56 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 53
ERROR - 2021-07-05 08:12:56 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 53
ERROR - 2021-07-05 08:12:56 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 53
ERROR - 2021-07-05 08:12:56 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 53
ERROR - 2021-07-05 08:12:56 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 53
ERROR - 2021-07-05 08:12:56 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 53
ERROR - 2021-07-05 08:12:56 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 53
ERROR - 2021-07-05 08:12:56 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 53
ERROR - 2021-07-05 08:12:56 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 53
ERROR - 2021-07-05 08:12:56 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 53
ERROR - 2021-07-05 08:12:56 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 53
ERROR - 2021-07-05 08:12:56 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 53
ERROR - 2021-07-05 08:12:56 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 53
ERROR - 2021-07-05 08:12:56 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 53
ERROR - 2021-07-05 08:12:56 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 53
ERROR - 2021-07-05 08:12:56 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 53
ERROR - 2021-07-05 08:12:56 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 53
ERROR - 2021-07-05 08:12:56 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 53
ERROR - 2021-07-05 08:12:56 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 53
ERROR - 2021-07-05 08:12:56 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 64
ERROR - 2021-07-05 08:12:56 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 64
ERROR - 2021-07-05 08:12:56 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 87
ERROR - 2021-07-05 08:12:56 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 87
ERROR - 2021-07-05 08:12:56 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 88
ERROR - 2021-07-05 08:12:56 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 88
ERROR - 2021-07-05 08:12:56 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 92
ERROR - 2021-07-05 08:12:56 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 92
ERROR - 2021-07-05 08:12:56 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 98
ERROR - 2021-07-05 08:12:56 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_equipos.php 98
ERROR - 2021-07-05 08:15:45 --> 404 Page Not Found: Admin/proyectos
ERROR - 2021-07-05 08:16:18 --> Severity: Warning --> Creating default object from empty value D:\xampp\htdocs\adt_prepa\application\controllers\Front_Proyectos.php 107
ERROR - 2021-07-05 08:16:18 --> 404 Page Not Found: Front_Proyectos/detalles
ERROR - 2021-07-05 08:21:42 --> Severity: Notice --> Undefined index: equipo D:\xampp\htdocs\adt_prepa\application\controllers\Front_Proyectos.php 237
ERROR - 2021-07-05 08:21:42 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\adt_prepa\application\controllers\Front_Proyectos.php 237
ERROR - 2021-07-05 08:23:30 --> Severity: error --> Exception: syntax error, unexpected ')' D:\xampp\htdocs\adt_prepa\application\views\default\front\front_detalles_proyecto.php 10
ERROR - 2021-07-05 13:39:30 --> Severity: Notice --> Undefined variable: consulta D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_proyectos.php 76
ERROR - 2021-07-05 13:39:30 --> Severity: Notice --> Undefined variable: proyectos D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_proyectos.php 115
ERROR - 2021-07-05 13:39:30 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_proyectos.php 115
ERROR - 2021-07-05 13:39:30 --> Severity: Notice --> Undefined variable: cantidad_paginas D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_proyectos.php 132
ERROR - 2021-07-05 13:39:42 --> Severity: Notice --> Undefined variable: consulta D:\xampp\htdocs\adt_prepa\application\controllers\Front_Proyectos.php 90
ERROR - 2021-07-05 13:49:40 --> Severity: Warning --> Creating default object from empty value D:\xampp\htdocs\adt_prepa\application\controllers\Front_Proyectos.php 107
ERROR - 2021-07-05 13:49:49 --> Severity: Notice --> Undefined variable: consulta D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_proyectos.php 76
ERROR - 2021-07-05 13:49:49 --> Severity: Notice --> Undefined variable: proyectos D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_proyectos.php 115
ERROR - 2021-07-05 13:49:49 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_proyectos.php 115
ERROR - 2021-07-05 13:49:49 --> Severity: Notice --> Undefined variable: cantidad_paginas D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_proyectos.php 132
ERROR - 2021-07-05 13:51:50 --> 404 Page Not Found: Proyecto/detalles
ERROR - 2021-07-05 13:53:01 --> Severity: Notice --> Undefined variable: proyectos D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_proyectos.php 41
ERROR - 2021-07-05 13:53:01 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_proyectos.php 41
ERROR - 2021-07-05 13:53:01 --> Severity: Notice --> Undefined variable: consulta D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_proyectos.php 110
ERROR - 2021-07-05 13:53:01 --> Severity: Notice --> Undefined variable: proyectos D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_proyectos.php 149
ERROR - 2021-07-05 13:53:01 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_proyectos.php 149
ERROR - 2021-07-05 13:53:01 --> Severity: Notice --> Undefined variable: cantidad_paginas D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_proyectos.php 166
ERROR - 2021-07-05 13:57:15 --> Severity: Notice --> Undefined variable: proyectos D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_proyectos.php 41
ERROR - 2021-07-05 13:57:15 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_proyectos.php 41
ERROR - 2021-07-05 13:57:15 --> Severity: Notice --> Undefined variable: proyectos D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_proyectos.php 149
ERROR - 2021-07-05 13:57:15 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_proyectos.php 149
ERROR - 2021-07-05 14:05:04 --> Severity: Notice --> Undefined variable: usuario D:\xampp\htdocs\adt_prepa\application\views\default\front\front_detalles_proyecto.php 46
ERROR - 2021-07-05 14:05:04 --> Severity: Notice --> Undefined variable: usuario D:\xampp\htdocs\adt_prepa\application\views\default\front\front_detalles_proyecto.php 46
ERROR - 2021-07-05 14:05:04 --> Severity: Notice --> Undefined variable: usuario D:\xampp\htdocs\adt_prepa\application\views\default\front\front_detalles_proyecto.php 46
ERROR - 2021-07-05 14:05:04 --> Severity: Notice --> Undefined variable: usuario D:\xampp\htdocs\adt_prepa\application\views\default\front\front_detalles_proyecto.php 46
ERROR - 2021-07-05 14:05:04 --> Severity: Notice --> Undefined variable: usuario D:\xampp\htdocs\adt_prepa\application\views\default\front\front_detalles_proyecto.php 46
ERROR - 2021-07-05 14:05:04 --> Severity: Notice --> Undefined variable: usuario D:\xampp\htdocs\adt_prepa\application\views\default\front\front_detalles_proyecto.php 46
ERROR - 2021-07-05 14:05:04 --> Severity: Notice --> Undefined variable: usuario D:\xampp\htdocs\adt_prepa\application\views\default\front\front_detalles_proyecto.php 46
ERROR - 2021-07-05 14:05:04 --> Severity: Notice --> Undefined variable: usuario D:\xampp\htdocs\adt_prepa\application\views\default\front\front_detalles_proyecto.php 46
ERROR - 2021-07-05 14:05:04 --> Severity: Notice --> Undefined variable: usuario D:\xampp\htdocs\adt_prepa\application\views\default\front\front_detalles_proyecto.php 46
ERROR - 2021-07-05 14:05:04 --> Severity: Notice --> Undefined variable: usuario D:\xampp\htdocs\adt_prepa\application\views\default\front\front_detalles_proyecto.php 46
ERROR - 2021-07-05 14:05:04 --> Severity: Notice --> Undefined variable: usuario D:\xampp\htdocs\adt_prepa\application\views\default\front\front_detalles_proyecto.php 46
ERROR - 2021-07-05 14:05:04 --> Severity: Notice --> Undefined variable: usuario D:\xampp\htdocs\adt_prepa\application\views\default\front\front_detalles_proyecto.php 46
ERROR - 2021-07-05 14:05:04 --> Severity: Notice --> Undefined variable: usuario D:\xampp\htdocs\adt_prepa\application\views\default\front\front_detalles_proyecto.php 46
ERROR - 2021-07-05 14:05:04 --> Severity: Notice --> Undefined variable: usuario D:\xampp\htdocs\adt_prepa\application\views\default\front\front_detalles_proyecto.php 46
ERROR - 2021-07-05 14:05:04 --> Severity: Notice --> Undefined variable: equipos D:\xampp\htdocs\adt_prepa\application\views\default\front\front_detalles_proyecto.php 56
ERROR - 2021-07-05 14:05:04 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\adt_prepa\application\views\default\front\front_detalles_proyecto.php 56
ERROR - 2021-07-05 14:05:04 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_detalles_proyecto.php 59
ERROR - 2021-07-05 14:05:04 --> Severity: Notice --> Trying to get property 'ID_EQUIPO' of non-object D:\xampp\htdocs\adt_prepa\application\views\default\front\front_detalles_proyecto.php 59
ERROR - 2021-07-05 14:05:04 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_detalles_proyecto.php 60
ERROR - 2021-07-05 14:05:04 --> Severity: Notice --> Trying to get property 'EQUIPO_NOMBRE' of non-object D:\xampp\htdocs\adt_prepa\application\views\default\front\front_detalles_proyecto.php 60
ERROR - 2021-07-05 14:08:07 --> Severity: Notice --> Undefined variable: usuario D:\xampp\htdocs\adt_prepa\application\views\default\front\front_detalles_proyecto.php 51
ERROR - 2021-07-05 14:08:07 --> Severity: Notice --> Undefined variable: usuario D:\xampp\htdocs\adt_prepa\application\views\default\front\front_detalles_proyecto.php 51
ERROR - 2021-07-05 14:08:07 --> Severity: Notice --> Undefined variable: usuario D:\xampp\htdocs\adt_prepa\application\views\default\front\front_detalles_proyecto.php 51
ERROR - 2021-07-05 14:08:07 --> Severity: Notice --> Undefined variable: usuario D:\xampp\htdocs\adt_prepa\application\views\default\front\front_detalles_proyecto.php 51
ERROR - 2021-07-05 14:08:07 --> Severity: Notice --> Undefined variable: usuario D:\xampp\htdocs\adt_prepa\application\views\default\front\front_detalles_proyecto.php 51
ERROR - 2021-07-05 14:08:07 --> Severity: Notice --> Undefined variable: usuario D:\xampp\htdocs\adt_prepa\application\views\default\front\front_detalles_proyecto.php 51
ERROR - 2021-07-05 14:08:07 --> Severity: Notice --> Undefined variable: usuario D:\xampp\htdocs\adt_prepa\application\views\default\front\front_detalles_proyecto.php 51
ERROR - 2021-07-05 14:08:07 --> Severity: Notice --> Undefined variable: usuario D:\xampp\htdocs\adt_prepa\application\views\default\front\front_detalles_proyecto.php 51
ERROR - 2021-07-05 14:08:07 --> Severity: Notice --> Undefined variable: usuario D:\xampp\htdocs\adt_prepa\application\views\default\front\front_detalles_proyecto.php 51
ERROR - 2021-07-05 14:08:07 --> Severity: Notice --> Undefined variable: usuario D:\xampp\htdocs\adt_prepa\application\views\default\front\front_detalles_proyecto.php 51
ERROR - 2021-07-05 14:08:07 --> Severity: Notice --> Undefined variable: usuario D:\xampp\htdocs\adt_prepa\application\views\default\front\front_detalles_proyecto.php 51
ERROR - 2021-07-05 14:08:07 --> Severity: Notice --> Undefined variable: usuario D:\xampp\htdocs\adt_prepa\application\views\default\front\front_detalles_proyecto.php 51
ERROR - 2021-07-05 14:08:07 --> Severity: Notice --> Undefined variable: usuario D:\xampp\htdocs\adt_prepa\application\views\default\front\front_detalles_proyecto.php 51
ERROR - 2021-07-05 14:08:07 --> Severity: Notice --> Undefined variable: usuario D:\xampp\htdocs\adt_prepa\application\views\default\front\front_detalles_proyecto.php 51
ERROR - 2021-07-05 14:08:07 --> Severity: Notice --> Undefined variable: equipos D:\xampp\htdocs\adt_prepa\application\views\default\front\front_detalles_proyecto.php 61
ERROR - 2021-07-05 14:08:07 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\adt_prepa\application\views\default\front\front_detalles_proyecto.php 61
ERROR - 2021-07-05 14:08:07 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_detalles_proyecto.php 64
ERROR - 2021-07-05 14:08:07 --> Severity: Notice --> Trying to get property 'ID_EQUIPO' of non-object D:\xampp\htdocs\adt_prepa\application\views\default\front\front_detalles_proyecto.php 64
ERROR - 2021-07-05 14:08:07 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_detalles_proyecto.php 65
ERROR - 2021-07-05 14:08:07 --> Severity: Notice --> Trying to get property 'EQUIPO_NOMBRE' of non-object D:\xampp\htdocs\adt_prepa\application\views\default\front\front_detalles_proyecto.php 65
ERROR - 2021-07-05 14:08:54 --> Severity: Notice --> Undefined variable: equipos D:\xampp\htdocs\adt_prepa\application\views\default\front\front_detalles_proyecto.php 43
ERROR - 2021-07-05 14:08:54 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\adt_prepa\application\views\default\front\front_detalles_proyecto.php 43
ERROR - 2021-07-05 14:08:54 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_detalles_proyecto.php 46
ERROR - 2021-07-05 14:08:54 --> Severity: Notice --> Trying to get property 'ID_EQUIPO' of non-object D:\xampp\htdocs\adt_prepa\application\views\default\front\front_detalles_proyecto.php 46
ERROR - 2021-07-05 14:08:54 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_detalles_proyecto.php 47
ERROR - 2021-07-05 14:08:54 --> Severity: Notice --> Trying to get property 'EQUIPO_NOMBRE' of non-object D:\xampp\htdocs\adt_prepa\application\views\default\front\front_detalles_proyecto.php 47
ERROR - 2021-07-05 14:09:19 --> Severity: Notice --> Undefined variable: equipos D:\xampp\htdocs\adt_prepa\application\views\default\front\front_detalles_proyecto.php 43
ERROR - 2021-07-05 14:09:19 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\adt_prepa\application\views\default\front\front_detalles_proyecto.php 43
ERROR - 2021-07-05 14:09:19 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_detalles_proyecto.php 46
ERROR - 2021-07-05 14:09:19 --> Severity: Notice --> Trying to get property 'ID_EQUIPO' of non-object D:\xampp\htdocs\adt_prepa\application\views\default\front\front_detalles_proyecto.php 46
ERROR - 2021-07-05 14:09:19 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_detalles_proyecto.php 47
ERROR - 2021-07-05 14:09:19 --> Severity: Notice --> Trying to get property 'EQUIPO_NOMBRE' of non-object D:\xampp\htdocs\adt_prepa\application\views\default\front\front_detalles_proyecto.php 47
ERROR - 2021-07-05 14:09:46 --> Severity: Notice --> Undefined variable: equipos D:\xampp\htdocs\adt_prepa\application\views\default\front\front_detalles_proyecto.php 37
ERROR - 2021-07-05 14:09:46 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\adt_prepa\application\views\default\front\front_detalles_proyecto.php 37
ERROR - 2021-07-05 14:09:46 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_detalles_proyecto.php 40
ERROR - 2021-07-05 14:09:46 --> Severity: Notice --> Trying to get property 'ID_EQUIPO' of non-object D:\xampp\htdocs\adt_prepa\application\views\default\front\front_detalles_proyecto.php 40
ERROR - 2021-07-05 14:09:46 --> Severity: Notice --> Undefined variable: equipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_detalles_proyecto.php 41
ERROR - 2021-07-05 14:09:46 --> Severity: Notice --> Trying to get property 'EQUIPO_NOMBRE' of non-object D:\xampp\htdocs\adt_prepa\application\views\default\front\front_detalles_proyecto.php 41
ERROR - 2021-07-05 14:20:03 --> Severity: Notice --> Undefined index: categoria D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_usuarios.php 17
ERROR - 2021-07-05 14:24:48 --> 404 Page Not Found: Admin/usuarios
ERROR - 2021-07-05 14:24:54 --> 404 Page Not Found: Admin/usuarios
ERROR - 2021-07-05 14:25:03 --> 404 Page Not Found: Admin/usuarios
ERROR - 2021-07-05 14:28:57 --> Severity: Notice --> Trying to get property 'USUARIO_NOMBRE' of non-object D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_usuarios.php 41
ERROR - 2021-07-05 14:28:57 --> Severity: Notice --> Trying to get property 'USUARIO_NOMBRE' of non-object D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_usuarios.php 41
ERROR - 2021-07-05 14:28:57 --> Severity: Notice --> Trying to get property 'USUARIO_NOMBRE' of non-object D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_usuarios.php 41
ERROR - 2021-07-05 14:31:21 --> Severity: Notice --> Undefined index: equipo D:\xampp\htdocs\adt_prepa\application\controllers\Front_Usuarios.php 295
ERROR - 2021-07-05 14:31:21 --> Severity: Notice --> Undefined variable: publicacion D:\xampp\htdocs\adt_prepa\application\views\default\front\front_detalles_usuario.php 4
ERROR - 2021-07-05 14:31:21 --> Severity: Notice --> Undefined variable: publicacion D:\xampp\htdocs\adt_prepa\application\views\default\front\front_detalles_usuario.php 8
ERROR - 2021-07-05 14:31:21 --> Severity: Notice --> Undefined variable: publicacion D:\xampp\htdocs\adt_prepa\application\views\default\front\front_detalles_usuario.php 22
ERROR - 2021-07-05 14:31:21 --> Severity: Notice --> Undefined variable: multimedia D:\xampp\htdocs\adt_prepa\application\views\default\front\front_detalles_usuario.php 25
ERROR - 2021-07-05 14:31:21 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\adt_prepa\application\views\default\front\front_detalles_usuario.php 25
ERROR - 2021-07-05 14:31:21 --> Severity: Notice --> Undefined variable: multimedia D:\xampp\htdocs\adt_prepa\application\views\default\front\front_detalles_usuario.php 37
ERROR - 2021-07-05 14:31:21 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\adt_prepa\application\views\default\front\front_detalles_usuario.php 37
ERROR - 2021-07-05 14:31:21 --> Severity: Notice --> Undefined variable: publicacion D:\xampp\htdocs\adt_prepa\application\views\default\front\front_detalles_usuario.php 86
ERROR - 2021-07-05 14:31:21 --> Severity: Notice --> Undefined variable: publicacion D:\xampp\htdocs\adt_prepa\application\views\default\front\front_detalles_usuario.php 92
ERROR - 2021-07-05 14:31:21 --> Severity: Notice --> Undefined variable: publicacion D:\xampp\htdocs\adt_prepa\application\views\default\front\front_detalles_usuario.php 93
ERROR - 2021-07-05 14:31:21 --> Severity: Notice --> Undefined variable: publicacion D:\xampp\htdocs\adt_prepa\application\views\default\front\front_detalles_usuario.php 115
ERROR - 2021-07-05 14:31:21 --> Severity: Notice --> Undefined variable: publicacion D:\xampp\htdocs\adt_prepa\application\views\default\front\front_detalles_usuario.php 119
ERROR - 2021-07-05 14:31:51 --> Severity: Notice --> Undefined variable: publicacion D:\xampp\htdocs\adt_prepa\application\views\default\front\front_detalles_usuario.php 4
ERROR - 2021-07-05 14:31:51 --> Severity: Notice --> Undefined variable: publicacion D:\xampp\htdocs\adt_prepa\application\views\default\front\front_detalles_usuario.php 8
ERROR - 2021-07-05 14:31:51 --> Severity: Notice --> Undefined variable: publicacion D:\xampp\htdocs\adt_prepa\application\views\default\front\front_detalles_usuario.php 22
ERROR - 2021-07-05 14:31:51 --> Severity: Notice --> Undefined variable: multimedia D:\xampp\htdocs\adt_prepa\application\views\default\front\front_detalles_usuario.php 25
ERROR - 2021-07-05 14:31:51 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\adt_prepa\application\views\default\front\front_detalles_usuario.php 25
ERROR - 2021-07-05 14:31:51 --> Severity: Notice --> Undefined variable: multimedia D:\xampp\htdocs\adt_prepa\application\views\default\front\front_detalles_usuario.php 37
ERROR - 2021-07-05 14:31:51 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\adt_prepa\application\views\default\front\front_detalles_usuario.php 37
ERROR - 2021-07-05 14:31:51 --> Severity: Notice --> Undefined variable: publicacion D:\xampp\htdocs\adt_prepa\application\views\default\front\front_detalles_usuario.php 86
ERROR - 2021-07-05 14:31:51 --> Severity: Notice --> Undefined variable: publicacion D:\xampp\htdocs\adt_prepa\application\views\default\front\front_detalles_usuario.php 92
ERROR - 2021-07-05 14:31:51 --> Severity: Notice --> Undefined variable: publicacion D:\xampp\htdocs\adt_prepa\application\views\default\front\front_detalles_usuario.php 93
ERROR - 2021-07-05 14:31:51 --> Severity: Notice --> Undefined variable: publicacion D:\xampp\htdocs\adt_prepa\application\views\default\front\front_detalles_usuario.php 115
ERROR - 2021-07-05 14:31:51 --> Severity: Notice --> Undefined variable: publicacion D:\xampp\htdocs\adt_prepa\application\views\default\front\front_detalles_usuario.php 119
ERROR - 2021-07-05 14:35:56 --> Severity: Notice --> Undefined index: EQUIPO_NOMBRE D:\xampp\htdocs\adt_prepa\application\views\default\front\front_detalles_usuario.php 13
ERROR - 2021-07-05 14:38:50 --> Severity: Notice --> Undefined variable: titulo D:\xampp\htdocs\adt_prepa\application\views\default\front\headers\header_principal.php 8
ERROR - 2021-07-05 14:38:50 --> Severity: Notice --> Undefined variable: titulo D:\xampp\htdocs\adt_prepa\application\views\default\front\headers\header_principal.php 13
ERROR - 2021-07-05 14:38:50 --> Severity: Notice --> Undefined variable: descripcion D:\xampp\htdocs\adt_prepa\application\views\default\front\headers\header_principal.php 14
ERROR - 2021-07-05 14:38:50 --> Severity: Notice --> Undefined variable: imagen D:\xampp\htdocs\adt_prepa\application\views\default\front\headers\header_principal.php 15
ERROR - 2021-07-05 14:38:50 --> Severity: Notice --> Undefined variable: titulo D:\xampp\htdocs\adt_prepa\application\views\default\front\headers\header_principal.php 89
ERROR - 2021-07-05 14:39:55 --> Severity: Notice --> Undefined variable: titulo D:\xampp\htdocs\adt_prepa\application\views\default\front\headers\header_principal.php 8
ERROR - 2021-07-05 14:39:55 --> Severity: Notice --> Undefined variable: titulo D:\xampp\htdocs\adt_prepa\application\views\default\front\headers\header_principal.php 13
ERROR - 2021-07-05 14:39:55 --> Severity: Notice --> Undefined variable: descripcion D:\xampp\htdocs\adt_prepa\application\views\default\front\headers\header_principal.php 14
ERROR - 2021-07-05 14:39:55 --> Severity: Notice --> Undefined variable: imagen D:\xampp\htdocs\adt_prepa\application\views\default\front\headers\header_principal.php 15
ERROR - 2021-07-05 14:39:55 --> Severity: Notice --> Undefined variable: titulo D:\xampp\htdocs\adt_prepa\application\views\default\front\headers\header_principal.php 89
ERROR - 2021-07-05 14:41:00 --> Severity: Notice --> Undefined variable: titulo D:\xampp\htdocs\adt_prepa\application\views\default\front\headers\header_principal.php 8
ERROR - 2021-07-05 14:41:00 --> Severity: Notice --> Undefined variable: titulo D:\xampp\htdocs\adt_prepa\application\views\default\front\headers\header_principal.php 13
ERROR - 2021-07-05 14:41:00 --> Severity: Notice --> Undefined variable: descripcion D:\xampp\htdocs\adt_prepa\application\views\default\front\headers\header_principal.php 14
ERROR - 2021-07-05 14:41:00 --> Severity: Notice --> Undefined variable: imagen D:\xampp\htdocs\adt_prepa\application\views\default\front\headers\header_principal.php 15
ERROR - 2021-07-05 14:41:00 --> Severity: Notice --> Undefined variable: titulo D:\xampp\htdocs\adt_prepa\application\views\default\front\headers\header_principal.php 89
ERROR - 2021-07-05 14:44:27 --> Severity: Notice --> Undefined index: categoria D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_usuarios.php 169
ERROR - 2021-07-05 14:44:27 --> Severity: Notice --> Undefined index: tipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_usuarios.php 170
ERROR - 2021-07-05 14:44:29 --> Severity: Notice --> Undefined index: categoria D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_usuarios.php 169
ERROR - 2021-07-05 14:44:29 --> Severity: Notice --> Undefined index: tipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_usuarios.php 170
ERROR - 2021-07-05 14:44:31 --> Severity: Notice --> Undefined index: categoria D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_usuarios.php 169
ERROR - 2021-07-05 14:44:31 --> Severity: Notice --> Undefined index: tipo D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_usuarios.php 170
ERROR - 2021-07-05 14:48:24 --> 404 Page Not Found: Usuarios_Inicio/perfil
ERROR - 2021-07-05 14:49:30 --> Severity: Warning --> Creating default object from empty value D:\xampp\htdocs\adt_prepa\application\controllers\Front_Proyectos.php 172
ERROR - 2021-07-05 14:49:33 --> Severity: Notice --> Undefined variable: consulta D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_tareas.php 45
ERROR - 2021-07-05 14:49:33 --> Severity: Notice --> Undefined variable: tareas D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_tareas.php 93
ERROR - 2021-07-05 14:49:33 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_tareas.php 93
ERROR - 2021-07-05 14:49:33 --> Severity: Notice --> Undefined variable: cantidad_paginas D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_tareas.php 127
ERROR - 2021-07-05 14:50:07 --> Severity: Notice --> Undefined variable: consulta D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_tareas.php 45
ERROR - 2021-07-05 14:50:07 --> Severity: Notice --> Undefined variable: tareas D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_tareas.php 93
ERROR - 2021-07-05 14:50:07 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_tareas.php 93
ERROR - 2021-07-05 14:50:07 --> Severity: Notice --> Undefined variable: cantidad_paginas D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_tareas.php 127
ERROR - 2021-07-05 14:50:39 --> Severity: Warning --> Creating default object from empty value D:\xampp\htdocs\adt_prepa\application\controllers\Front_Equipos.php 173
ERROR - 2021-07-05 14:52:59 --> Query error: Column 'ID_USUARIO' in group statement is ambiguous - Invalid query: SELECT *
FROM `usuarios`
JOIN `equipos_usuarios` ON `equipos_usuarios`.`ID_USUARIO` = `usuarios`.`ID_USUARIO`
WHERE   (
`usuarios`.`ESTADO` = 'activo'
 )
GROUP BY `ID_USUARIO`
ORDER BY `usuarios`.`USUARIO_NOMBRE` ASC
ERROR - 2021-07-05 15:07:07 --> 404 Page Not Found: Admin/tareas
ERROR - 2021-07-05 15:17:56 --> Query error: Unknown column 'ASIGNACION' in 'field list' - Invalid query: INSERT INTO `usuarios_tareas` (`ID_USUARIO`, `ID_TAREA`, `ASIGNACION`, `FECHA_ASIGNACION`, `ESTADO`) VALUES ('5f400557ec9b74.36456554', 7, 'produccion', '2021-07-05 15:17:56', 'activo')
ERROR - 2021-07-05 15:21:23 --> 404 Page Not Found: Front_Tareas/detalles
ERROR - 2021-07-05 15:22:44 --> Severity: Notice --> Undefined variable: proyecto D:\xampp\htdocs\adt_prepa\application\views\default\front\front_detalles_proyecto.php 4
ERROR - 2021-07-05 15:22:44 --> Severity: Notice --> Undefined variable: proyecto D:\xampp\htdocs\adt_prepa\application\views\default\front\front_detalles_proyecto.php 20
ERROR - 2021-07-05 15:22:44 --> Severity: Notice --> Undefined variable: tareas D:\xampp\htdocs\adt_prepa\application\views\default\front\front_detalles_proyecto.php 76
ERROR - 2021-07-05 15:22:44 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\adt_prepa\application\views\default\front\front_detalles_proyecto.php 76
ERROR - 2021-07-05 15:28:09 --> Severity: Notice --> Undefined variable: usuarios D:\xampp\htdocs\adt_prepa\application\views\default\front\front_detalles_tarea.php 14
ERROR - 2021-07-05 15:28:09 --> Severity: Notice --> Trying to get property 'this' of non-object D:\xampp\htdocs\adt_prepa\application\views\default\front\front_detalles_tarea.php 14
ERROR - 2021-07-05 15:28:09 --> Severity: Notice --> Trying to get property 'GeneralModel' of non-object D:\xampp\htdocs\adt_prepa\application\views\default\front\front_detalles_tarea.php 14
ERROR - 2021-07-05 15:28:09 --> Severity: error --> Exception: Call to a member function lista() on null D:\xampp\htdocs\adt_prepa\application\views\default\front\front_detalles_tarea.php 14
ERROR - 2021-07-05 15:28:20 --> Severity: Notice --> Trying to get property 'ID_TAREA' of non-object D:\xampp\htdocs\adt_prepa\application\views\default\front\front_detalles_tarea.php 14
ERROR - 2021-07-05 15:37:10 --> Query error: Unknown column 'proyectos.ESTADO' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM (
SELECT *
FROM `tareas`
WHERE   (
`proyectos`.`ESTADO` != 'borrador'
 )
GROUP BY `tareas`.`ID_TAREA`
) CI_count_all_results
ERROR - 2021-07-05 15:37:48 --> Severity: Notice --> Undefined property: stdClass::$IMAGEN D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_tareas.php 97
ERROR - 2021-07-05 15:37:48 --> Severity: Notice --> Undefined property: stdClass::$IMAGEN D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_tareas.php 97
ERROR - 2021-07-05 15:37:48 --> Severity: Notice --> Undefined property: stdClass::$IMAGEN D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_tareas.php 97
ERROR - 2021-07-05 15:37:48 --> Severity: Notice --> Undefined property: stdClass::$IMAGEN D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_tareas.php 97
ERROR - 2021-07-05 15:37:48 --> Severity: Notice --> Undefined property: stdClass::$IMAGEN D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_tareas.php 97
ERROR - 2021-07-05 15:39:15 --> Severity: Notice --> Undefined property: stdClass::$IMAGEN D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_tareas.php 99
ERROR - 2021-07-05 15:39:15 --> Severity: Notice --> Undefined property: stdClass::$IMAGEN D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_tareas.php 99
ERROR - 2021-07-05 15:39:15 --> Severity: Notice --> Undefined property: stdClass::$IMAGEN D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_tareas.php 99
ERROR - 2021-07-05 15:39:15 --> Severity: Notice --> Undefined property: stdClass::$IMAGEN D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_tareas.php 99
ERROR - 2021-07-05 15:39:15 --> Severity: Notice --> Undefined property: stdClass::$IMAGEN D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_tareas.php 99
ERROR - 2021-07-05 15:39:20 --> Severity: Notice --> Undefined property: stdClass::$IMAGEN D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_tareas.php 99
ERROR - 2021-07-05 15:39:20 --> Severity: Notice --> Undefined property: stdClass::$IMAGEN D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_tareas.php 99
ERROR - 2021-07-05 15:39:20 --> Severity: Notice --> Undefined property: stdClass::$IMAGEN D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_tareas.php 99
ERROR - 2021-07-05 15:39:20 --> Severity: Notice --> Undefined property: stdClass::$IMAGEN D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_tareas.php 99
ERROR - 2021-07-05 15:39:20 --> Severity: Notice --> Undefined property: stdClass::$IMAGEN D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_tareas.php 99
ERROR - 2021-07-05 15:39:23 --> Severity: Notice --> Undefined property: stdClass::$IMAGEN D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_tareas.php 99
ERROR - 2021-07-05 15:39:23 --> Severity: Notice --> Undefined property: stdClass::$IMAGEN D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_tareas.php 99
ERROR - 2021-07-05 15:39:23 --> Severity: Notice --> Undefined property: stdClass::$IMAGEN D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_tareas.php 99
ERROR - 2021-07-05 15:39:23 --> Severity: Notice --> Undefined property: stdClass::$IMAGEN D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_tareas.php 99
ERROR - 2021-07-05 15:39:23 --> Severity: Notice --> Undefined property: stdClass::$IMAGEN D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_tareas.php 99
ERROR - 2021-07-05 15:40:54 --> 404 Page Not Found: Front_Tareas/actualizar
ERROR - 2021-07-05 18:14:13 --> 404 Page Not Found: Front_Tareas/actualizar
ERROR - 2021-07-05 18:14:18 --> 404 Page Not Found: Front_Tareas/actualizar
ERROR - 2021-07-05 18:44:37 --> Severity: Notice --> Undefined index: equipo D:\xampp\htdocs\adt_prepa\application\controllers\Front_Tareas.php 235
ERROR - 2021-07-05 18:44:37 --> Severity: Notice --> Undefined variable: titulo D:\xampp\htdocs\adt_prepa\application\views\default\admin\header_principal.php 8
ERROR - 2021-07-05 18:44:37 --> Severity: Notice --> Undefined variable: titulo D:\xampp\htdocs\adt_prepa\application\views\default\admin\header_principal.php 13
ERROR - 2021-07-05 18:44:37 --> Severity: Notice --> Undefined variable: descripcion D:\xampp\htdocs\adt_prepa\application\views\default\admin\header_principal.php 14
ERROR - 2021-07-05 18:44:37 --> Severity: Notice --> Undefined variable: imagen D:\xampp\htdocs\adt_prepa\application\views\default\admin\header_principal.php 15
ERROR - 2021-07-05 18:44:56 --> Severity: Notice --> Undefined variable: titulo D:\xampp\htdocs\adt_prepa\application\views\default\admin\header_principal.php 8
ERROR - 2021-07-05 18:44:56 --> Severity: Notice --> Undefined variable: titulo D:\xampp\htdocs\adt_prepa\application\views\default\admin\header_principal.php 13
ERROR - 2021-07-05 18:44:56 --> Severity: Notice --> Undefined variable: descripcion D:\xampp\htdocs\adt_prepa\application\views\default\admin\header_principal.php 14
ERROR - 2021-07-05 18:44:56 --> Severity: Notice --> Undefined variable: imagen D:\xampp\htdocs\adt_prepa\application\views\default\admin\header_principal.php 15
ERROR - 2021-07-05 18:45:35 --> Severity: Notice --> Undefined variable: titulo D:\xampp\htdocs\adt_prepa\application\views\default\front\headers\header_principal.php 8
ERROR - 2021-07-05 18:45:35 --> Severity: Notice --> Undefined variable: titulo D:\xampp\htdocs\adt_prepa\application\views\default\front\headers\header_principal.php 13
ERROR - 2021-07-05 18:45:35 --> Severity: Notice --> Undefined variable: descripcion D:\xampp\htdocs\adt_prepa\application\views\default\front\headers\header_principal.php 14
ERROR - 2021-07-05 18:45:35 --> Severity: Notice --> Undefined variable: imagen D:\xampp\htdocs\adt_prepa\application\views\default\front\headers\header_principal.php 15
ERROR - 2021-07-05 18:45:35 --> Severity: Notice --> Undefined variable: titulo D:\xampp\htdocs\adt_prepa\application\views\default\front\headers\header_principal.php 89
ERROR - 2021-07-05 18:45:35 --> Severity: Notice --> Undefined variable: proyecto D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_tarea.php 4
ERROR - 2021-07-05 18:45:35 --> Severity: Notice --> Undefined variable: proyecto D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_tarea.php 25
ERROR - 2021-07-05 18:45:35 --> Severity: Notice --> Undefined variable: proyecto D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_tarea.php 29
ERROR - 2021-07-05 18:45:51 --> Severity: Notice --> Undefined variable: proyecto D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_tarea.php 4
ERROR - 2021-07-05 18:45:51 --> Severity: Notice --> Undefined variable: proyecto D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_tarea.php 25
ERROR - 2021-07-05 18:45:51 --> Severity: Notice --> Undefined variable: proyecto D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_tarea.php 29
ERROR - 2021-07-05 18:58:51 --> Severity: error --> Exception: syntax error, unexpected '=>' (T_DOUBLE_ARROW) D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_tarea.php 19
ERROR - 2021-07-05 19:01:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_tarea.php 50
ERROR - 2021-07-05 19:01:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_tarea.php 50
ERROR - 2021-07-05 19:01:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given D:\xampp\htdocs\adt_prepa\application\views\default\front\front_form_actualizar_tarea.php 50
ERROR - 2021-07-05 20:16:27 --> Query error: Unknown column 'ID_CATEGORIA' in 'where clause' - Invalid query: UPDATE `tareas` SET `ID_PROYECTO` = '1', `ID_TAREA_PADRE` = 0, `TAREA_TITULO` = 'Nueva tarea', `TAREA_DESCRIPCION` = 'hkajslajslkjas', `TAREA_ENLACE_EDITABLES` = '', `TAREA_ENLACE_ENTREGABLE` = '', `PRIORIDAD` = 'normal', `TIPO` = 'general', `ESTADO` = 'en desarrollo'
WHERE `ID_CATEGORIA` = '7'
ERROR - 2021-07-05 20:17:04 --> Severity: Notice --> Undefined variable: tarea_id D:\xampp\htdocs\adt_prepa\application\controllers\Front_Tareas.php 209
ERROR - 2021-07-05 20:17:04 --> Query error: Column 'ID_TAREA' cannot be null - Invalid query: INSERT INTO `usuarios_tareas` (`ID_USUARIO`, `ID_TAREA`, `USUARIO_ASIGNACION`, `FECHA_ASIGNACION`, `ESTADO`) VALUES ('5f400557ec9b74.36456554', NULL, 'produccion', '2021-07-05 20:17:04', 'activo')
ERROR - 2021-07-05 20:20:34 --> Severity: Notice --> Undefined property: stdClass::$IMAGEN D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_tareas.php 99
ERROR - 2021-07-05 20:20:34 --> Severity: Notice --> Undefined property: stdClass::$IMAGEN D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_tareas.php 99
ERROR - 2021-07-05 20:20:34 --> Severity: Notice --> Undefined property: stdClass::$IMAGEN D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_tareas.php 99
ERROR - 2021-07-05 20:20:34 --> Severity: Notice --> Undefined property: stdClass::$IMAGEN D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_tareas.php 99
ERROR - 2021-07-05 20:20:34 --> Severity: Notice --> Undefined property: stdClass::$IMAGEN D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_tareas.php 99
ERROR - 2021-07-05 20:21:25 --> Severity: Notice --> Undefined property: stdClass::$IMAGEN D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_tareas.php 99
ERROR - 2021-07-05 20:21:25 --> Severity: Notice --> Undefined property: stdClass::$IMAGEN D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_tareas.php 99
ERROR - 2021-07-05 20:21:25 --> Severity: Notice --> Undefined property: stdClass::$IMAGEN D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_tareas.php 99
ERROR - 2021-07-05 20:21:25 --> Severity: Notice --> Undefined property: stdClass::$IMAGEN D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_tareas.php 99
ERROR - 2021-07-05 20:21:25 --> Severity: Notice --> Undefined property: stdClass::$IMAGEN D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_tareas.php 99
ERROR - 2021-07-05 20:41:41 --> Severity: Notice --> Undefined property: stdClass::$IMAGEN D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_tareas.php 99
ERROR - 2021-07-05 20:41:41 --> Severity: Notice --> Undefined property: stdClass::$IMAGEN D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_tareas.php 99
ERROR - 2021-07-05 20:41:41 --> Severity: Notice --> Undefined property: stdClass::$IMAGEN D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_tareas.php 99
ERROR - 2021-07-05 20:41:41 --> Severity: Notice --> Undefined property: stdClass::$IMAGEN D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_tareas.php 99
ERROR - 2021-07-05 20:41:41 --> Severity: Notice --> Undefined property: stdClass::$IMAGEN D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_tareas.php 99
ERROR - 2021-07-05 20:51:52 --> Severity: Notice --> Undefined property: stdClass::$IMAGEN D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_tareas.php 99
ERROR - 2021-07-05 20:51:52 --> Severity: Notice --> Undefined property: stdClass::$IMAGEN D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_tareas.php 99
ERROR - 2021-07-05 20:51:52 --> Severity: Notice --> Undefined property: stdClass::$IMAGEN D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_tareas.php 99
ERROR - 2021-07-05 20:51:52 --> Severity: Notice --> Undefined property: stdClass::$IMAGEN D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_tareas.php 99
ERROR - 2021-07-05 20:51:52 --> Severity: Notice --> Undefined property: stdClass::$IMAGEN D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_tareas.php 99
ERROR - 2021-07-05 20:52:08 --> Query error: Unknown column 'usuarios_tareas.ID_USUARIO' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM (
SELECT *
FROM `tareas`
WHERE   (
`tareas`.`ESTADO` != 'borrador'
AND `usuarios_tareas`.`ID_USUARIO` = '5c0653d43d92e7.75019474'
 )
GROUP BY `tareas`.`ID_TAREA`
) CI_count_all_results
ERROR - 2021-07-05 20:54:16 --> Severity: Notice --> Undefined property: stdClass::$IMAGEN D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_tareas.php 99
ERROR - 2021-07-05 20:54:16 --> Severity: Notice --> Undefined property: stdClass::$IMAGEN D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_tareas.php 99
ERROR - 2021-07-05 20:54:24 --> Severity: Notice --> Undefined property: stdClass::$IMAGEN D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_tareas.php 99
ERROR - 2021-07-05 20:54:24 --> Severity: Notice --> Undefined property: stdClass::$IMAGEN D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_tareas.php 99
ERROR - 2021-07-05 20:54:39 --> Severity: Notice --> Undefined property: stdClass::$IMAGEN D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_tareas.php 99
ERROR - 2021-07-05 20:54:39 --> Severity: Notice --> Undefined property: stdClass::$IMAGEN D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_tareas.php 99
ERROR - 2021-07-05 20:56:34 --> Severity: error --> Exception: syntax error, unexpected ')', expecting ',' or ';' D:\xampp\htdocs\adt_prepa\application\views\default\front\front_lista_usuarios.php 33
ERROR - 2021-07-05 20:56:43 --> Severity: Warning --> Creating default object from empty value D:\xampp\htdocs\adt_prepa\application\controllers\Front_Usuarios.php 119
ERROR - 2021-07-05 20:57:55 --> Severity: Notice --> Undefined variable: titulo D:\xampp\htdocs\adt_prepa\application\views\default\front\headers\header_principal.php 8
ERROR - 2021-07-05 20:57:55 --> Severity: Notice --> Undefined variable: titulo D:\xampp\htdocs\adt_prepa\application\views\default\front\headers\header_principal.php 13
ERROR - 2021-07-05 20:57:55 --> Severity: Notice --> Undefined variable: descripcion D:\xampp\htdocs\adt_prepa\application\views\default\front\headers\header_principal.php 14
ERROR - 2021-07-05 20:57:55 --> Severity: Notice --> Undefined variable: imagen D:\xampp\htdocs\adt_prepa\application\views\default\front\headers\header_principal.php 15
ERROR - 2021-07-05 20:57:55 --> Severity: Notice --> Undefined variable: titulo D:\xampp\htdocs\adt_prepa\application\views\default\front\headers\header_principal.php 89
ERROR - 2021-07-05 20:59:04 --> 404 Page Not Found: Admin/usuarios
ERROR - 2021-07-05 20:59:49 --> Severity: Notice --> Undefined index: telefono_sitio D:\xampp\htdocs\adt_prepa\application\views\default\emails\mensaje_general.php 146
ERROR - 2021-07-05 20:59:49 --> Severity: Notice --> Undefined index: direccion_sitio D:\xampp\htdocs\adt_prepa\application\views\default\emails\mensaje_general.php 147
ERROR - 2021-07-05 21:01:02 --> Severity: Notice --> Undefined index: telefono_sitio D:\xampp\htdocs\adt_prepa\application\views\default\emails\mensaje_general.php 146
ERROR - 2021-07-05 21:01:02 --> Severity: Notice --> Undefined index: direccion_sitio D:\xampp\htdocs\adt_prepa\application\views\default\emails\mensaje_general.php 147
ERROR - 2021-07-05 21:01:58 --> Severity: Notice --> Undefined index: telefono_sitio D:\xampp\htdocs\adt_prepa\application\views\default\emails\mensaje_general.php 146
ERROR - 2021-07-05 21:01:58 --> Severity: Notice --> Undefined index: direccion_sitio D:\xampp\htdocs\adt_prepa\application\views\default\emails\mensaje_general.php 147
