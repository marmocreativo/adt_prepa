<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-11-25 00:03:48 --> 404 Page Not Found: Admin_Tareas/detalles
ERROR - 2020-11-25 00:04:52 --> 404 Page Not Found: Admin_Tareas/detalles
