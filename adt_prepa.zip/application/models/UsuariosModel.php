<?php

if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class UsuariosModel extends CI_Model {

  function __construct()
  {
      parent::__construct();
      // Función Construct
  }
  // Funciones exclusivas para Usuarios

}
?>
